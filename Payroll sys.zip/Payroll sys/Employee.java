import java.io.*;

// Custom Exception
class InvalidPayrollDataException extends Exception {
    public InvalidPayrollDataException(String message) {
        super(message);
    }
}

// Base class
abstract class Employee {
    protected int empId;
    protected String name;

    public Employee(int empId, String name) {
        this.empId = empId;
        this.name = name;
    }

    abstract double calculatePay() throws InvalidPayrollDataException;

    public void generatePayslip(String empType, double pay) {
        try (PrintWriter writer = new PrintWriter(new FileWriter("payslip_" + empId + ".txt"))) {
            writer.println("=== PAYSLIP ===");
            writer.println("Employee ID: " + empId);
            writer.println("Name       : " + name);
            writer.println("Type       : " + empType);
            writer.printf("Pay Amount : ₹%.2f\n", pay);
            writer.println("=================");
            System.out.println("Payslip generated for " + name + " (empId: " + empId + ")");
        } catch (IOException e) {
            System.out.println("Error writing payslip: " + e.getMessage());
        }
    }
}