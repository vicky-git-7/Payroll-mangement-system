// Subclass 2: Salaried employee
class Salemp extends Employee {
    private double monthlySalary;

    public Salemp(int empId, String name, double monthlySalary) {
        super(empId, name);
        this.monthlySalary = monthlySalary;
    }

    @Override
    double calculatePay() throws InvalidPayrollDataException {
        if (monthlySalary < 0) {
            throw new InvalidPayrollDataException("Invalid salary for salaried employee.");
        }
        return monthlySalary;
    }
}