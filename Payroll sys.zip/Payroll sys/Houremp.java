// Subclass 1: Hourly employee
class HourlyEmployee extends Employee {
    private double hoursWorked;
    private double hourlyRate;

    public HourlyEmployee(int empId, String name, double hoursWorked, double hourlyRate) {
        super(empId, name);
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;
    }

    @Override
    double calculatePay() throws InvalidPayrollDataException {
        if (hoursWorked < 0 || hourlyRate < 0) {
            throw new InvalidPayrollDataException("Invalid hours or rate for hourly employee.");
        }
        return hoursWorked * hourlyRate;
    }
}