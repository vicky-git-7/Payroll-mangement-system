import java.util.*;
public class Payroll {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.println("=== Payroll Management System ===");
            System.out.print("Enter Employee ID: ");
            int id = sc.nextInt();
            sc.nextLine(); // consume newline
            System.out.print("Enter Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Employee Type (hourly/salaried): ");
            String type = sc.nextLine().toLowerCase();

            Employee emp;
            double pay;

            if (type.equals("hourly")) {
                System.out.print("Enter hours worked: ");
                double hours = sc.nextDouble();
                System.out.print("Enter hourly rate: ");
                double rate = sc.nextDouble();

                emp = new HourlyEmployee(id, name, hours, rate);
                pay = emp.calculatePay();
                emp.generatePayslip("Hourly", pay);

            } else if (type.equals("salaried")) {
                System.out.print("Enter monthly salary: ");
                double salary = sc.nextDouble();

                emp = new Salemp(id, name, salary);
                pay = emp.calculatePay();
                emp.generatePayslip("Salaried", pay);

            } else {
                System.out.println("Invalid employee type.");
            }

        } catch (InvalidPayrollDataException e) {
            System.out.println("Payroll Error: " + e.getMessage());
        } catch (InputMismatchException e) {
            System.out.println("Input type error. Please enter numeric values where required.");
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}